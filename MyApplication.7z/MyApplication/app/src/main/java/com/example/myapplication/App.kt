package com.example.myapplication
import android.app.Application
class App:Application() {
    override fun onCreate() {
        super.onCreate()
    }
}